# Consultancy Interview Prep App
This is a placeholder README for your project.